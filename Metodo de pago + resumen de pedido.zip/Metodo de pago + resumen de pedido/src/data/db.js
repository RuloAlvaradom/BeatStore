export const db = [
    {
        id: 1,
        name: "Ernie Ball Slinky 10-46",
        image: "img/guitarras/cuerdas1.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 10990
    },
    {
        id: 2,
        name: "D'Addario EJ16 Bronce 80/20",
        image: "img/guitarras/cuerdas2.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 14500
    },
    {
        id: 3,
        name: "Savarez Alliance Clásica",
        image: "img/guitarras/cuerdas3.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 17990
    },
    {
        id: 4,
        name: "Guitarra Acústica Yamaha F310P",
        image: "img/guitarras/guitarraacustica1.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 159990
    },
    {
        id: 5,
        name: "Fender FA-125 Dreadnought",
        image: "img/guitarras/guitarraacustica2.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 219900
    },
    {
        id: 6,
        name: "Ibanez PF15CE Electroacústica",
        image: "img/guitarras/guitarraacustica3.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 249990
    },
    {
        id: 7,
        name: "Squier Affinity Telecaster",
        image: "img/guitarras/guitarraelectrica1.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 249990
    },
    {
        id: 8,
        name: "Epiphone Les Paul Special VE",
        image: "img/guitarras/guitarraelectrica2.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 199900
    },
    {
        id: 9,
        name: "Ibanez GRG121DX Series",
        image: "img/guitarras/guitarraelectrica3.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 289990
    },
    {
        id: 10,
        name: "Fender CD-60SCE Dreadnought",
        image: "img/guitarras/guitarraelectroacustica1.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 319990
    },
    {
        id: 11,
        name: "Takamine GD30CE-NAT Dreadnought",
        image: "img/guitarras/guitarraelectroacustica2.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 449900
    },
    {
        id: 12,
        name: "Cort AD810E OP",
        image: "img/guitarras/guitarraelectroacustica3.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 225000
    },
    {
        id: 13,
        name: "Squier Affinity Jazz Bass",
        image: "img/bajos/bajoelectrico1.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 279990
    },
    {
        id: 14,
        name: "Ibanez GSR200 Gio Bass",
        image: "img/bajos/bajoelectrico2.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 249900
    },
    {
        id: 15,
        name: "Yamaha TRBX174",
        image: "img/bajos/bajoelectrico3.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 299990
    },
    {
        id: 16,
        name: "Ibanez PCBE12MH",
        image: "img/bajos/bajoelectroacustico1.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 215000
    },
    {
        id: 17,
        name: "Fender CB-60SCE",
        image: "img/bajos/bajoelectroacustico2.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 369900
    },
    {
        id: 18,
        name: "Yamaha APX500 Bass",
        image: "img/bajos/bajoelectroacustico3.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 320990
    },
    {
        id: 19,
        name: "Mástil Jazz Bass 20 Trastes (Arce)",
        image: "img/bajos/mastil1.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 125990
    },
    {
        id: 20,
        name: "Mástil Precision Bass (Rosewood)",
        image: "img/bajos/mastil2.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 149900
    },
    {
        id: 21,
        name: "Mástil Bajo 5 Cuerdas (24 Trastes)",
        image: "img/bajos/mastil3.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 175500
    },
    {
        id: 22,
        name: "Baquetas Vic Firth 5A",
        image: "img/percusion/baquetas1.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 15990
    },
    {
        id: 23,
        name: "Baquetas Promark 7A Oak",
        image: "img/percusion/baquetas2.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 14500
    },
    {
        id: 24,
        name: "Baquetas Hot Rods de Bambú",
        image: "img/percusion/baquetas3.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 22990
    },
    {
        id: 25,
        name: "Batería Acústica Pearl Roadshow",
        image: "img/percusion/baterias1.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 499990
    },
    {
        id: 26,
        name: "Batería Electrónica Alesis Nitro Mesh",
        image: "img/percusion/baterias2.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 399900
    },
    {
        id: 27,
        name: "Batería Acústica Tama Imperialstar",
        image: "img/percusion/baterias3.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 750000
    },
    {
        id: 28,
        name: "Set Congas LP Aspire Madera",
        image: "img/percusion/congas1.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 450990
    },
    {
        id: 29,
        name: "Conga Meinl Headliner 11\"",
        image: "img/percusion/congas2.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 219900
    },
    {
        id: 30,
        name: "Set Congas LP Matador Fibra",
        image: "img/percusion/congas3.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 799900
    },
    {
        id: 31,
        name: "Pandereta Meinl ABS",
        image: "img/percusion/percusionmenor1.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 18990
    },
    {
        id: 32,
        name: "Set de Maracas Profesionales",
        image: "img/percusion/percusionmenor2.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 35500
    },
    {
        id: 33,
        name: "Cencerro LP Aspire 5\"",
        image: "img/percusion/percusionmenor3.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 29990
    },
    {
        id: 34,
        name: "Sennheiser HD 280 Pro",
        image: "img/sonido/auriculares1.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 129990
    },
    {
        id: 35,
        name: "Sony MDR-7506",
        image: "img/sonido/auriculares2.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 99900
    },
    {
        id: 36,
        name: "Audio-Technica ATH-M50x",
        image: "img/sonido/auriculares3.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 169990
    },
    {
        id: 37,
        name: "Rode NT1-A Condensador",
        image: "img/sonido/microfonos1.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 199900
    },
    {
        id: 38,
        name: "Shure SM58 Dinámico",
        image: "img/sonido/microfonos2.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 119990
    },
    {
        id: 39,
        name: "Blue Yeti USB",
        image: "img/sonido/microfonos3.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 109900
    },
    {
        id: 40,
        name: "Monitor de Estudio Yamaha HS5 (Unidad)",
        image: "img/sonido/monitores1.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 169990
    },
    {
        id: 41,
        name: "Monitor de Estudio KRK Rokit 5 G4 (Par)",
        image: "img/sonido/monitores2.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 459900
    },
    {
        id: 42,
        name: "Monitor de Estudio PreSonus Eris E3.5 (Par)",
        image: "img/sonido/monitores3.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 134990
    },
    {
        id: 43,
        name: "Piano Vertical Yamaha B1",
        image: "img/teclados/pianosacusticos1.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 2890000
    },
    {
        id: 44,
        name: "Piano de Cola Kawai GL-10",
        image: "img/teclados/pianosacusticos2.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 11500000
    },
    {
        id: 45,
        name: "Piano Vertical Samick JS-115",
        image: "img/teclados/pianosacusticos3.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 1990000
    },
    {
        id: 46,
        name: "Piano Digital Yamaha P-45",
        image: "img/teclados/pianoselectricos1.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 459990
    },
    {
        id: 47,
        name: "Casio Privia PX-770",
        image: "img/teclados/pianoselectricos2.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 699900
    },
    {
        id: 48,
        name: "Roland FP-30X",
        image: "img/teclados/pianoselectricos3.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 789990
    },
    {
        id: 49,
        name: "Sintetizador Korg Volca Keys",
        image: "img/teclados/tecladosdigitales1.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 129990
    },
    {
        id: 50,
        name: "Teclado Portátil Yamaha PSR-E373",
        image: "img/teclados/tecladosdigitales2.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 215900
    },
    {
        id: 51,
        name: "Controlador MIDI Akai MPK Mini Play",
        image: "img/teclados/tecladosdigitales3.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 99900
    },
    {
        id: 52,
        name: "Polera Fender Vintage Logo",
        image: "img/coleccionables/merch1.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 24990
    },
    {
        id: 53,
        name: "Taza Gibson Coffee Mug",
        image: "img/coleccionables/merch2.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 12500
    },
    {
        id: 54,
        name: "Gorra LP Carbon",
        image: "img/coleccionables/merch3.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 30990
    },
    {
        id: 55,
        name: "Poster Histórico Gibson Les Paul",
        image: "img/coleccionables/posters1.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 14990
    },
    {
        id: 56,
        name: "Poster Michael Jackson Thriller Album",
        image: "img/coleccionables/posters2.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 9990
    },
    {
        id: 57,
        name: "Poster Guns N' Roses Dormitorio",
        image: "img/coleccionables/posters3.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 29990
    },
    {
        id: 58,
        name: "Pink Floyd - The Dark Side of the Moon",
        image: "img/coleccionables/vinilos1.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 34990
    },
    {
        id: 59,
        name: "Michael Jackson - Thriller",
        image: "img/coleccionables/vinilos2.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 29900
    },
    {
        id: 60,
        name: "The Beatles - Abbey Road",
        image: "img/coleccionables/vinilos3.jpg",
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.',
        price: 39990
    },

    // Productos destacados del Home
  {
    id: 101,
    name: "Squier Affinity Telecaster",
    description:
      "Guitarra eléctrica de cuerpo sólido, ideal para principiantes y músicos intermedios. Sonido clásico Fender con excelente sustain.",
    image: "img/guitarras/guitarraelectrica1.jpg",
    price: 249990,
    category: "Guitarras eléctricas",
  },
  {
    id: 102,
    name: "Micrófono Rode NT1-A",
    description:
      "Micrófono de condensador de estudio con respuesta cálida y extremadamente baja distorsión. Ideal para grabaciones vocales y acústicas.",
    image: "img/sonido/microfonos1.jpg",
    price: 199900,
    category: "Micrófonos",
  },
  {
    id: 103,
    name: "Batería Pearl Roadshow",
    description:
      "Set de batería completo con cascos de álamo, hardware robusto y un sonido potente. Perfecta para ensayos y presentaciones en vivo.",
    image: "img/percusion/baterias1.jpg",
    price: 499990,
    category: "Baterías",
  },

];