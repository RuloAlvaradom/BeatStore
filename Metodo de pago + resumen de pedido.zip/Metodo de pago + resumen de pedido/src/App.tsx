import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import "./assets/estilos.css";

import NavbarBeatStore from "./components/NavbarBeatStore";
import FooterBeatStore from "./components/FooterBeatStore";

import Home from "./pages/Home";
import Guitarras from "./pages/Guitarras";
import Bajos from "./pages/Bajos";
import Percusion from "./pages/Percusion";
import Teclados from "./pages/Teclados";
import Audio from "./pages/Audio";
import Accesorios from "./pages/Accesorios";
import Registro from "./pages/Registro";
import Contacto from "./pages/Contacto";

function App() {
  return (
    <Router>
      <NavbarBeatStore />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/guitarras" element={<Guitarras />} />
        <Route path="/bajos" element={<Bajos />} />
        <Route path="/percusion" element={<Percusion />} />
        <Route path="/teclados" element={<Teclados />} />
        <Route path="/audio" element={<Audio />} />
        <Route path="/accesorios" element={<Accesorios />} />
        <Route path="/registro" element={<Registro />} />
        <Route path="/contacto" element={<Contacto />} />
      </Routes>
      <FooterBeatStore />
    </Router>
  );
}

export default App;



