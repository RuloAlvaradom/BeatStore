import { useState } from "react";
import { Container, Form, Button, Alert } from "react-bootstrap";

const Registro = () => {
  const [nombre, setNombre] = useState("");
  const [correo, setCorreo] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [mensaje, setMensaje] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!nombre || !correo || !password || !confirmPassword) {
      setMensaje("Todos los campos son obligatorios.");
      return;
    }

    if (!correo.includes("@") || !correo.includes(".")) {
      setMensaje("Ingresa un correo electrónico válido.");
      return;
    }

    if (password !== confirmPassword) {
      setMensaje("Las contraseñas no coinciden.");
      return;
    }

    setMensaje("✅ Registro exitoso. ¡Bienvenido a BeatStore!");
    setNombre("");
    setCorreo("");
    setPassword("");
    setConfirmPassword("");
  };

  return (
    <Container className="my-5" style={{ maxWidth: "500px" }}>
      <h2 className="text-center mb-4">Registro de Usuario</h2>

      {mensaje && (
        <Alert variant={mensaje.includes("✅") ? "success" : "danger"}>
          {mensaje}
        </Alert>
      )}

      <Form onSubmit={handleSubmit}>
        <Form.Group className="mb-3">
          <Form.Label>Nombre</Form.Label>
          <Form.Control
            type="text"
            value={nombre}
            onChange={(e) => setNombre(e.target.value)}
            placeholder="Tu nombre completo"
          />
        </Form.Group>

        <Form.Group className="mb-3">
          <Form.Label>Correo electrónico</Form.Label>
          <Form.Control
            type="email"
            value={correo}
            onChange={(e) => setCorreo(e.target.value)}
            placeholder="ejemplo@correo.com"
          />
        </Form.Group>

        <Form.Group className="mb-3">
          <Form.Label>Contraseña</Form.Label>
          <Form.Control
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="********"
          />
        </Form.Group>

        <Form.Group className="mb-3">
          <Form.Label>Confirmar contraseña</Form.Label>
          <Form.Control
            type="password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            placeholder="********"
          />
        </Form.Group>

        <Button type="submit" className="w-100 btn-dark">
          Registrarme
        </Button>
      </Form>
    </Container>
  );
};

export default Registro;

