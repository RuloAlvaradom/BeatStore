import { useState } from "react";

function Registro() {
  const [nombre, setNombre] = useState("");
  const [correo, setCorreo] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const manejarEnvio = (e) => {
    e.preventDefault();

    if (!nombre || !correo || !password || !confirmPassword) {
      alert("Todos los campos son obligatorios.");
      return;
    }

    if (!correo.includes("@") || !correo.includes(".")) {
      alert("Ingresa un correo electrónico válido.");
      return;
    }

    if (password !== confirmPassword) {
      alert("Las contraseñas no coinciden.");
      return;
    }

    alert("Registro exitoso. ¡Bienvenido a BeatStore!");
    setNombre("");
    setCorreo("");
    setPassword("");
    setConfirmPassword("");
  };

  return (
    <div className="container my-5">
      <h2 className="text-center mb-4">Registro</h2>
      <form className="mx-auto" style={{ maxWidth: "400px" }} onSubmit={manejarEnvio}>
        <div className="mb-3">
          <label className="form-label">Nombre completo</label>
          <input
            type="text"
            className="form-control"
            value={nombre}
            onChange={(e) => setNombre(e.target.value)}
          />
        </div>

        <div className="mb-3">
          <label className="form-label">Correo electrónico</label>
          <input
            type="email"
            className="form-control"
            value={correo}
            onChange={(e) => setCorreo(e.target.value)}
          />
        </div>

        <div className="mb-3">
          <label className="form-label">Contraseña</label>
          <input
            type="password"
            className="form-control"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>

        <div className="mb-3">
          <label className="form-label">Confirmar contraseña</label>
          <input
            type="password"
            className="form-control"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
          />
        </div>

        <button type="submit" className="btn btn-dark w-100">
          Registrarme
        </button>
      </form>
    </div>
  );
}

export default Registro;
