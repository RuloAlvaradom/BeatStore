import { Container, Row, Col, Card, Button } from "react-bootstrap";

export default function Percusion() {
  return (
    <Container className="my-5">
      <h1 className="text-center mb-4">Percusión</h1>
      <Row>

        <Col md={4} className="mb-4">
          <Card>
            <Card.Img variant="top" src="img/percusion/percusion1.jpg" alt="Bateria electrica" />
            <Card.Body className="text-center">
              <Card.Title>Bateria electrica</Card.Title>
              <Card.Text>$1.299.990 CLP</Card.Text>
              <Card.Text>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.
              </Card.Text>
              <Button variant="primary">Agregar al carrito</Button>
            </Card.Body>
          </Card>
        </Col>

        <Col md={4} className="mb-4">
          <Card>
            <Card.Img variant="top" src="img/percusion/percusion2.jpg" alt="Congas LP ASPIRE" />
            <Card.Body className="text-center">
              <Card.Title>Congas LP ASPIRE</Card.Title>
              <Card.Text>$899.990 CLP</Card.Text>
              <Card.Text>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.
              </Card.Text>
              <Button variant="primary">Agregar al carrito</Button>
            </Card.Body>
          </Card>
        </Col>

        <Col md={4} className="mb-4">
          <Card>
            <Card.Img variant="top" src="img/percusion/percusion3.jpg" alt="PAR BAQUETAS TIMBALES 1/2" />
            <Card.Body className="text-center">
              <Card.Title>PAR BAQUETAS TIMBALES 1/2</Card.Title>
              <Card.Text>$60.990 CLP</Card.Text>
              <Card.Text>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.
              </Card.Text>
              <Button variant="primary">Agregar al carrito</Button>
            </Card.Body>
          </Card>
        </Col>

        <Col md={4} className="mb-4">
          <Card>
            <Card.Img variant="top" src="img/percusion/percusion4.jpg" alt="Batería Acústica Tama Stagestar" />
            <Card.Body className="text-center">
              <Card.Title>Batería Acústica Tama Stagestar</Card.Title>
              <Card.Text>$640.990 CLP</Card.Text>
              <Card.Text>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.
              </Card.Text>
              <Button variant="primary">Agregar al carrito</Button>
            </Card.Body>
          </Card>
        </Col>

        <Col md={4} className="mb-4">
          <Card>
            <Card.Img variant="top" src="img/percusion/percusion5.jpg" alt="BONGO LP ASPIRE DE FIBRA 6-3/4" />
            <Card.Body className="text-center">
              <Card.Title>BONGO LP ASPIRE DE FIBRA 6-3/4</Card.Title>
              <Card.Text>$158.990 CLP</Card.Text>
              <Card.Text>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.
              </Card.Text>
              <Button variant="primary">Agregar al carrito</Button>
            </Card.Body>
          </Card>
        </Col>

        <Col md={4} className="mb-4">
          <Card>
            <Card.Img variant="top" src="img/percusion/percusion6.jpg" alt="Set de Platillos Sabian HHX Evolution" />
            <Card.Body className="text-center">
              <Card.Title>Set de Platillos Sabian HHX Evolution</Card.Title>
              <Card.Text>$1.600.000 CLP</Card.Text>
              <Card.Text>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.
              </Card.Text>
              <Button variant="primary">Agregar al carrito</Button>
            </Card.Body>
          </Card>
        </Col>

        <Col md={4} className="mb-4">
          <Card>
            <Card.Img variant="top" src="img/percusion/percusion7.jpg" alt="shaker Meinl" />
            <Card.Body className="text-center">
              <Card.Title>shaker Meinl</Card.Title>
              <Card.Text>$25.000 CLP</Card.Text>
              <Card.Text>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.
              </Card.Text>
              <Button variant="primary">Agregar al carrito</Button>
            </Card.Body>
          </Card>
        </Col>
          
        <Col md={4} className="mb-4">
          <Card>
            <Card.Img variant="top" src="img/percusion/percusion8.jpg" alt="Baqueta Vic Firth madera 5B" />
            <Card.Body className="text-center">
              <Card.Title>Baqueta Vic Firth madera 5B</Card.Title>
              <Card.Text>$16.900 CLP</Card.Text>
              <Card.Text>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.
              </Card.Text>
              <Button variant="primary">Agregar al carrito</Button>
            </Card.Body>
          </Card>
        </Col>

        <Col md={4} className="mb-4">
          <Card>
            <Card.Img variant="top" src="img/percusion/percusion9.jpg" alt="CORTINA 25B LP449 LP PERCUSION" />
            <Card.Body className="text-center">
              <Card.Title>CORTINA 25B LP449 LP PERCUSION</Card.Title>
              <Card.Text>$34.900 CLP</Card.Text>
              <Card.Text>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.
              </Card.Text>
              <Button variant="primary">Agregar al carrito</Button>
            </Card.Body>
          </Card>
        </Col>

      </Row>
    </Container>
  );
}


