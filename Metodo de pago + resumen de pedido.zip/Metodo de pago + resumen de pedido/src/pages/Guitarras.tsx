import { Container, Row, Col, Card, Button } from "react-bootstrap"
import { useCarrito } from "../hooks/useCarrito"


export default function Guitarras() {
  const { addToCart } = useCarrito();

  return (
    <Container className="my-5">
      <h2 className="text-center mb-4">🎸 Guitarras</h2>
      <Row>
        <Col md={4} className="mb-4">
          <Card>
            <Card.Img variant="top" src="/img/guitarras/guitarra1.jpg" alt="GUITARRA ELECTRICA TAGIMA" />
              <Card.Body className="text-center">
                 <Card.Title>GUITARRA ELECTRICA TAGIMA</Card.Title>
                  <Card.Text>$329.900 CLP</Card.Text>
                    <Card.Text>
                      Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.
                    </Card.Text>
                      <Button 
                        variant="dark" 
                        onClick={() => addToCart({
                        id: 1,
                        name: "GUITARRA ELECTRICA TAGIMA",
                        price: 329900,
                        image: "/img/guitarras/guitarra1.jpg"
                      })}
      >
        Agregar al carrito
      </Button>
    </Card.Body>
  </Card>
</Col>

        <Col md={4} className="mb-4">
          <Card>
            <Card.Img variant="top" src="/img/guitarras/guitarra3.jpg" alt="Guitarra Clásica Yamaha C40 En Caja - Naranja" />
            <Card.Body className="text-center">
              <Card.Title>Guitarra Clásica Yamaha C40</Card.Title>
              <Card.Text>$139.990 CLP</Card.Text>
              <Card.Text>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.
              </Card.Text>
              <Button variant="dark">Agregar al carrito</Button>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  );
}

