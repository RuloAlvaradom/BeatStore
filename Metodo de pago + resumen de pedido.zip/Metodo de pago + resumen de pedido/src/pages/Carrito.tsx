import { useState } from "react";
import { Container, Table, Button } from "react-bootstrap";

const Carrito = () => {
  const [carrito, setCarrito] = useState([
    { id: 1, nombre: "Guitarra Eléctrica", precio: 199990 },
    { id: 2, nombre: "Vinilo Clásico", precio: 12999 },
  ]);

  const eliminarProducto = (id: number) => {
    setCarrito(carrito.filter((item) => item.id !== id));
  };

  const total = carrito.reduce((sum, item) => sum + item.precio, 0);

  return (
    <Container className="my-5">
      <h2 className="text-center mb-4">🛒 Tu Carrito</h2>

      {carrito.length === 0 ? (
        <p className="text-center">Tu carrito está vacío 😢</p>
      ) : (
        <>
          <Table striped bordered hover>
            <thead className="table-dark text-center">
              <tr>
                <th>Producto</th>
                <th>Precio</th>
                <th>Acción</th>
              </tr>
            </thead>
            <tbody>
              {carrito.map((item) => (
                <tr key={item.id}>
                  <td>{item.nombre}</td>
                  <td>${item.precio.toLocaleString()} CLP</td>
                  <td className="text-center">
                    <Button
                      variant="danger"
                      size="sm"
                      onClick={() => eliminarProducto(item.id)}
                    >
                      Eliminar
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </Table>

          <h4 className="text-end">
            Total: <span className="text-success">${total.toLocaleString()} CLP</span>
          </h4>

          <div className="text-end mt-3">
            <Button variant="dark">Finalizar compra</Button>
          </div>
        </>
      )}
    </Container>
  );
};

export default Carrito;

