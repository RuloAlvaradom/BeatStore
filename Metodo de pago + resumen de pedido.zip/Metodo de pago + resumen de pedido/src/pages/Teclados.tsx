import { Container, Row, Col, Card, Button } from "react-bootstrap";

export default function TecladosPianos() {
  return (
    <Container className="my-5">
      <h1 className="text-center mb-4">Teclados y Pianos</h1>
      <Row>

        <Col md={4} className="mb-4">
          <Card>
            <Card.Img variant="top" src="img/teclados/piano1.jpg" alt="PIANO DE COLA" />
            <Card.Body className="text-center">
              <Card.Title>PIANO DE COLA</Card.Title>
              <Card.Text>$10.000.990 CLP</Card.Text>
              <Card.Text>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.
              </Card.Text>
              <Button variant="primary">Agregar al carrito</Button>
            </Card.Body>
          </Card>
        </Col>

        <Col md={4} className="mb-4">
          <Card>
            <Card.Img variant="top" src="img/teclados/piano2.jpg" alt="Yamaha P225B - Piano Digital" />
            <Card.Body className="text-center">
              <Card.Title>Yamaha P225B - Piano Digital</Card.Title>
              <Card.Text>$899.990 CLP</Card.Text>
              <Card.Text>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.
              </Card.Text>
              <Button variant="primary">Agregar al carrito</Button>
            </Card.Body>
          </Card>
        </Col>

        <Col md={4} className="mb-4">
          <Card>
            <Card.Img variant="top" src="img/teclados/piano3.jpg" alt="Teclado Electrónico pedal" />
            <Card.Body className="text-center">
              <Card.Title>Teclado Electrónico pedal</Card.Title>
              <Card.Text>$39.990 CLP</Card.Text>
              <Card.Text>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.
              </Card.Text>
              <Button variant="primary">Agregar al carrito</Button>
            </Card.Body>
          </Card>
        </Col>

      </Row>
    </Container>
  );
}


