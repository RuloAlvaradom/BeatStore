import React from 'react';
import { Container, Row, Col, Card, Button } from 'react-bootstrap'; 

const Home: React.FC = () => {
  return (
    <Container className="my-5">
      <section className="text-center p-5 bg-dark text-white rounded mb-5">
        <h1 className="fw-bold">
          Bienvenido a <span className="text-warning">BeatStore</span>
        </h1>
        <p className="lead">Tu tienda online de música e instrumentos 🎶</p>
      </section>

      <div id="carouselBeatStore" className="carousel slide mb-5" data-bs-ride="carousel">
        <div className="carousel-inner rounded shadow">
          <div className="carousel-item active">
            <img src="/img/carrusel1.jpg" className="d-block w-100" alt="Instrumentos" />
          </div>
          <div className="carousel-item">
            <img src="/img/carrusel2.jpg" className="d-block w-100" alt="Vinilos" />
          </div>
          <div className="carousel-item">
            <img src="/img/carrusel3.jpg" className="d-block w-100" alt="Baterías" />
          </div>
        </div>
        <button className="carousel-control-prev" type="button" data-bs-target="#carouselBeatStore" data-bs-slide="prev">
          <span className="carousel-control-prev-icon" aria-hidden="true"></span>
          <span className="visually-hidden">Anterior</span>
        </button>
        <button className="carousel-control-next" type="button" data-bs-target="#carouselBeatStore" data-bs-slide="next">
          <span className="carousel-control-next-icon" aria-hidden="true"></span>
          <span className="visually-hidden">Siguiente</span>
        </button>
      </div>

      <section className="mb-5">
        <h2 className="text-center mb-4">Ofertas de la Semana</h2>
        <Row>
          {[
            { img: '/img/guitarras/guitarra1.jpg', title: 'Guitarra Acústica', oldPrice: '$329.900 CLP', price: '$159.990 CLP' },
            { img: '/img/bajos/bajo1.jpg', title: 'Bajo Jazz', oldPrice: '$299.990 CLP', price: '$199.990 CLP' },
            { img: '/img/percusion/percusion1.jpg', title: 'Bateria Electronica', oldPrice: '$1.299.990 CLP', price: '$1.000.000 CLP' },
          ].map((prod, i) => (
            <Col md={4} key={i} className="mb-4">
              <Card>
                <Card.Img variant="top" src={prod.img} />
                <Card.Body className="text-center">
                  <Card.Title>{prod.title}</Card.Title>
                  <p>
                    <del>{prod.oldPrice}</del>{' '}
                    <span className="text-danger fw-bold">{prod.price}</span>
                  </p>
                  <Button variant="warning" className="text-dark fw-bold">
                    Agregar al carrito
                  </Button>
                </Card.Body>
              </Card>
            </Col>
          ))}
        </Row>
      </section>

      <section>
        <h2 className="text-center mb-4">Marcas con las que trabajamos</h2>
        <div className="d-flex justify-content-center flex-wrap gap-4">
          <img src="/img/marcas/fender.png" alt="Fender" width="120" />
          <img src="/img/marcas/gibson.png" alt="Gibson" width="120" />
          <img src="/img/marcas/yamaha.png" alt="Yamaha" width="120" />
          <img src="/img/marcas/roland.png" alt="Roland" width="120" />
        </div>
      </section>
    </Container>
  );
};

export default Home;
