import { Container, Row, Col, Card, Button } from "react-bootstrap";

export default function Coleccionables() {
  return (
    <Container className="my-5">
      <h1 className="text-center mb-4">Coleccionables</h1>
      <Row>

        <Col md={4} className="mb-4">
          <Card>
            <Card.Img variant="top" src="img/coleccionables/vinilo1.jpg" alt="Disco de vinilo" />
            <Card.Body className="text-center">
              <Card.Title>Disco de vinilo</Card.Title>
              <Card.Text>$12.999 CLP</Card.Text>
              <Card.Text>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.
              </Card.Text>
              <Button variant="primary">Agregar al carrito</Button>
            </Card.Body>
          </Card>
        </Col>

        <Col md={4} className="mb-4">
          <Card>
            <Card.Img variant="top" src="img/coleccionables/poster2.jpg" alt="Set de Posters" />
            <Card.Body className="text-center">
              <Card.Title>Set de Posters</Card.Title>
              <Card.Text>$9.990 CLP</Card.Text>
              <Card.Text>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.
              </Card.Text>
              <Button variant="primary">Agregar al carrito</Button>
            </Card.Body>
          </Card>
        </Col>

        <Col md={4} className="mb-4">
          <Card>
            <Card.Img variant="top" src="img/coleccionables/disco3.jpg" alt="MICHAEL JACKSON - BAD 25 - 2CD" />
            <Card.Body className="text-center">
              <Card.Title>MICHAEL JACKSON - BAD 25 - 2CD</Card.Title>
              <Card.Text>$20.990 CLP</Card.Text>
              <Card.Text>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.
              </Card.Text>
              <Button variant="primary">Agregar al carrito</Button>
            </Card.Body>
          </Card>
        </Col>

      </Row>
    </Container>
  );
}

