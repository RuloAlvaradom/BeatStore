import { Container, Row, Col, Card, Button } from "react-bootstrap";

export default function Audio() {
  return (
    <Container className="my-5">
      <h1 className="text-center mb-4">Audio</h1>
      <Row>

        <Col md={4} className="mb-4">
          <Card>
            <Card.Img variant="top" src="img/sonido/sonido1.jpg" alt="Soundcraft EPM12" />
            <Card.Body className="text-center">
              <Card.Title>Soundcraft EPM12</Card.Title>
              <Card.Text>$564,060 CLP</Card.Text>
              <Card.Text>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.
              </Card.Text>
              <Button variant="primary">Agregar al carrito</Button>
            </Card.Body>
          </Card>
        </Col>

        <Col md={4} className="mb-4">
          <Card>
            <Card.Img variant="top" src="img/sonido/sonido2.jpg" alt="Micrófono consumer Samson R21S con switchz" />
            <Card.Body className="text-center">
              <Card.Title>Micrófono consumer R21S con switch</Card.Title>
              <Card.Text>$59.990 CLP</Card.Text>
              <Card.Text>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.
              </Card.Text>
              <Button variant="primary">Agregar al carrito</Button>
            </Card.Body>
          </Card>
        </Col>

        <Col md={4} className="mb-4">
          <Card>
            <Card.Img variant="top" src="img/sonido/sonido3.jpg" alt="Cable de micrófono XLR/Jack - 3m" />
            <Card.Body className="text-center">
              <Card.Title>Cable de micrófono XLR/Jack - 3m</Card.Title>
              <Card.Text>$25.590 CLP</Card.Text>
              <Card.Text>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.
              </Card.Text>
              <Button variant="primary">Agregar al carrito</Button>
            </Card.Body>
          </Card>
        </Col>

      </Row>
    </Container>
  );
}


