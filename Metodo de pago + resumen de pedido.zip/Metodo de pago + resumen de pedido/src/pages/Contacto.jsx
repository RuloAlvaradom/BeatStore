export default function Contacto() {
  return (
    <div className="container my-5">
      <section className="text-center p-5 bg-dark text-white rounded mb-5">
        <h1 className="fw-bold">
          Bienvenido a <span className="text-warning">BeatStore</span>
        </h1>
        <p className="lead">Tu tienda online de música e instrumentos 🎶</p>
      </section>
      {/* Aquí va el resto del contenido (carrusel, ofertas, etc.) */}
    </div>
  );
}
