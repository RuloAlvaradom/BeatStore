import { Container, Row, Col, Card, Button } from "react-bootstrap";

export default function Bajos() {
  return (
    <Container className="my-5">
      <h1 className="text-center mb-4">Bajos</h1>
      <Row>

        <Col md={4} className="mb-4">
          <Card>
            <Card.Img variant="top" src="img/bajos/bajo1.jpg" alt="Bajo Fender Jazz" />
            <Card.Body className="text-center">
              <Card.Title>Squier CLASSIC VIBE 70 JAZZ</Card.Title>
              <Card.Text>$299.990 CLP</Card.Text>
              <Card.Text>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.
              </Card.Text>
              <Button variant="primary">Agregar al carrito</Button>
            </Card.Body>
          </Card>
        </Col>

        <Col md={4} className="mb-4">
          <Card>
            <Card.Img variant="top" src="img/bajos/bajo2.jpg" alt="Bajo Ibanez" />
            <Card.Body className="text-center">
              <Card.Title>Bajo Ibanez</Card.Title>
              <Card.Text>$249.990 CLP</Card.Text>
              <Card.Text>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.
              </Card.Text>
              <Button variant="primary">Agregar al carrito</Button>
            </Card.Body>
          </Card>
        </Col>

        <Col md={4} className="mb-4">
          <Card>
            <Card.Img variant="top" src="img/bajos/bajo3.jpg" alt="Bajo Yamaha" />
            <Card.Body className="text-center">
              <Card.Title>Bajo Fender Jazz</Card.Title>
              <Card.Text>$189.990 CLP</Card.Text>
              <Card.Text>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean varius mattis pellentesque. Ut in leo eget sem pretium aliquam a in libero.
              </Card.Text>
              <Button variant="primary">Agregar al carrito</Button>
            </Card.Body>
          </Card>
        </Col>

      </Row>
    </Container>
  );
}


