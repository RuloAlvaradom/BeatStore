import { Card, Button } from "react-bootstrap";

export default function ProductCard({ imgSrc, title, price }) {
  return (
    <Card className="h-100 shadow-sm">
      <Card.Img
        variant="top"
        src={imgSrc}
        alt={title}
        style={{ height: "250px", objectFit: "cover" }}
      />
      <Card.Body className="text-center">
        <Card.Title>{title}</Card.Title>
        <Card.Text>{price}</Card.Text>
        <Button variant="dark">Agregar al carrito</Button>
      </Card.Body>
    </Card>
  );
}

