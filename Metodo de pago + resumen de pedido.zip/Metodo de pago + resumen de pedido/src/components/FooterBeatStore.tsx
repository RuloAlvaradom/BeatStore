export default function FooterBeatStore() {
  return (
    <footer className="bg-dark text-white text-center py-3 mt-5">
      <p>&copy; 2025 BeatStore - Todos los derechos reservados</p>
    </footer>
  );
}
