export default function FooterBeatStore() {
  return (
    <footer className="bg-dark text-light text-center py-3 mt-5">
      <p className="mb-0">&copy; 2025 BeatStore - Todos los derechos reservados 🎵</p>
    </footer>
  );
}

