import { Link } from "react-router-dom";

export default function NavbarBeatStore() {
  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
      <div className="container">
        <Link className="navbar-brand d-flex align-items-center" to="/">
          <img src="/img/logo.png" alt="BeatStore Logo" width="80" className="me-2" />
          <span className="fs-3 fw-bold">BeatStore</span>
        </Link>

        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
          <span className="navbar-toggler-icon"></span>
        </button>

        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav ms-auto">
            <li className="nav-item"><Link className="nav-link" to="/guitarras">Guitarras</Link></li>
            <li className="nav-item"><Link className="nav-link" to="/bajos">Bajos</Link></li>
            <li className="nav-item"><Link className="nav-link" to="/percusion">Percusión</Link></li>
            <li className="nav-item"><Link className="nav-link" to="/teclados">Teclados y Pianos</Link></li>
            <li className="nav-item"><Link className="nav-link" to="/audio">Audio</Link></li>
            <li className="nav-item"><Link className="nav-link" to="/accesorios">Coleccionables</Link></li>
            <li className="nav-item"><Link className="nav-link" to="/contacto">Contacto</Link></li>
            <li className="nav-item"><Link className="nav-link" to="/registro">Registro</Link></li>
            <li className="nav-item"><Link className="nav-link" to="/carrito">🛒 Carrito</Link></li>
          </ul>
        </div>
      </div>
    </nav>
  );
}
